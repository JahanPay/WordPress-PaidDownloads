<?php

/*
Plugin Name: درگاه پرداخت و کیف پول الکترونیک جهان پی- افزونه دانلود به ازای پرداخت
Version: 1.0.0
Description: تنظیمات درگاه پرداخت جهان پی برای افزونه دانلود به ازای پرداخت
Plugin URI: https://jahanpay.me/
Author: jahanpay.me
Author URI: https://jahanpay.me/
*/

require_once('class-paid-downloads-jahanpay.php');
